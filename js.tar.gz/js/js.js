window.addEventListener("load", function()
{
    let logo=document.querySelectorAll(".navbar-brand")[0].firstElementChild;
    console.log(logo);
    let x=Math.random() * (screen.width);
    let y=Math.random() * (screen.height);
    logo.style.marginTop=x;
    logo.style.marginLeft=y;
    logo.style.zIndex=1;
    console.log(x);
    console.log(y);
});


(function() {
    
    var mX, mY, distance,
        $distance = $('#distance span'),
        $element  = $('#catch');
        let c=document.querySelectorAll("#catch")[0];
    function calculateDistance(elem, mouseX, mouseY) {
        return Math.floor(Math.sqrt(Math.pow(mouseX - (elem.offset().left+(elem.width()/2)), 2) + Math.pow(mouseY - (elem.offset().top+(elem.height()/2)), 2)));
    }

    $(document).mousemove(function(e) {  
        mX = e.pageX;
        mY = e.pageY;
        distance = calculateDistance($element, mX, mY);
        $distance.text(distance);
        if(distance<250)
            {
                let x=Math.random() * (screen.width);
                let y=Math.random() * (screen.height);
                c.style.top=x;
                c.style.left=y;
                
            }         
    });
})();


let trick = document.querySelector(".trick");

trick.addEventListener("click", function () {
    let audio_trick = document.querySelector("#audio_trick");
    if (audio_trick) {
        audio_trick.play()
            .then(() => {
                console.log("Audio is playing!");
            })
            .catch(error => {
                console.error("Failed to play audio:", error);
            });
    } else {
        console.error("Audio element not found.");
    }
});
