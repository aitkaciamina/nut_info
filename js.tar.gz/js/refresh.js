window.addEventListener("load", function()
{
    let logo=document.querySelectorAll(".navbar-brand")[0].firstElementChild;
    console.log(logo);
    let x=Math.random() * (screen.width);
    let y=Math.random() * (screen.height);
    logo.style.marginTop=x;
    logo.style.marginLeft=y;
    logo.style.zIndex=1;
    console.log(x);
    console.log(y);
});
