
function hideShow(event)
{
    let titre = event.currentTarget;
    let video = titre.nextElementSibling.nextElementSibling;

    video.classList.toggle('hide');
}


let titre = document.querySelector("h3.video_title");

titre.addEventListener('click',hideShow)

