function hideShow2(event)
{
    let titre = event.currentTarget;
    let audio = titre.nextElementSibling;

    audio.classList.toggle('hide');
}


let titre1 = document.querySelector("#title1");

titre1.addEventListener('click',hideShow2);
